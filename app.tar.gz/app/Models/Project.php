<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Project extends Model
{
    use HasTranslations;

    public $translatable = [
        'title',
        'name',
        'location',
        'description',
        'info'
    ];

    protected $fillable = [
        'title',
        'name',
        'location',
        'description',
        'info',
        'year',
        'has_detail',
        'status',
        'competition',
        'publish',
        'order',
        'category_id',
        'category_type_id',
        'order'
    ];

    /**
     * Relationships
     */

    public function images()
    {
        return $this->hasMany('App\Models\ProjectImage');
    }

    public function downloads()
    {
        return $this->hasMany('App\Models\ProjectFile');
    }

    public function category()
    {
        return $this->belongsTo('App\Models\Category');
    }

    public function categoryType()
    {
        return $this->belongsTo('App\Models\CategoryType');
    }

    /**
     * Get only published records
     *
     * @param  \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */

    public function scopePublished($query)
    {
        return $query->where('publish', '=', '1');
    }

    /**
     * Get only published records
     *
     * @param  \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */

    public function scopeCompetition($query)
    {
        return $query->where('competition', '!=', NULL);
    }
}

