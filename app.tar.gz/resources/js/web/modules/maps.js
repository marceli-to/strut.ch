var MapsUi = (function() {
	
	var selectors = {
		body:	   'body',
		container: 'js-maps', // id!
	};
	
	var coords = {
		lat: 47.504199,
		lng: 8.721944
	};

	var zoom = 15;

	var _initialize = function() {
	    
    if ($(selectors.body).find('#' + selectors.container).length < 1) {
      return;
    }
    
    var myLatlng = new google.maps.LatLng(coords.lat,coords.lng);
    var mapOptions = {
        center: myLatlng,
        zoom: zoom,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    var styles = [{
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#f5f5f5"
        }
      ]
    },
    {
      "elementType": "labels.icon",
      "stylers": [
        {
          "visibility": "off"
        }
      ]
    },
    {
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#616161"
        }
      ]
    },
    {
      "elementType": "labels.text.stroke",
      "stylers": [
        {
          "color": "#f5f5f5"
        }
      ]
    },
    {
      "featureType": "administrative.land_parcel",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#bdbdbd"
        }
      ]
    },
    {
      "featureType": "poi",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#eeeeee"
        }
      ]
    },
    {
      "featureType": "poi",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#757575"
        }
      ]
    },
    {
      "featureType": "poi.park",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#e5e5e5"
        }
      ]
    },
    {
      "featureType": "poi.park",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#9e9e9e"
        }
      ]
    },
    {
      "featureType": "road",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#ffffff"
        }
      ]
    },
    {
      "featureType": "road.arterial",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#757575"
        }
      ]
    },
    {
      "featureType": "road.highway",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#dadada"
        }
      ]
    },
    {
      "featureType": "road.highway",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#616161"
        }
      ]
    },
    {
      "featureType": "road.local",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#9e9e9e"
        }
      ]
    },
    {
      "featureType": "transit.line",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#e5e5e5"
        }
      ]
    },
    {
      "featureType": "transit.station",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#eeeeee"
        }
      ]
    },
    {
      "featureType": "water",
      "elementType": "geometry",
      "stylers": [
        {
          "color": "#c9c9c9"
        }
      ]
    },
    {
      "featureType": "water",
      "elementType": "labels.text.fill",
      "stylers": [
        {
          "color": "#9e9e9e"
        }
      ]
    }];

    var map = new google.maps.Map(document.getElementById(selectors.container),mapOptions);
        map.setOptions({styles: styles});

    // Map markers
    // var markerIcon = '/assets/img/icons/marker.svg';
    // var marker = new google.maps.Marker({
    //     position: myLatlng,
    //     map: map,
    //     icon: markerIcon
    // });

    var marker = new google.maps.Marker({
      position: myLatlng,
      map: map,
      icon: {
        anchor: new google.maps.Point(10, 80),
        url: 'data:image/svg+xml;utf-8, \
        <svg viewBox="0 0 132.8 124.6" xmlns="http://www.w3.org/2000/svg"><path d="m132.8 0h-132.8v63.8 11.4 49.4l17.6-49.4h115.2z" fill="black"/><g fill="white"><path d="m104.2 24.2h4.3v16.5c0 5.3 3.2 7 6.5 7a10.8 10.8 0 0 0 3.5-.4l-.4-3.5a5.8 5.8 0 0 1 -1.9.3c-3.1 0-3.6-1.4-3.6-4.2v-15.7h6v-3.3h-6v-7h-4.1v7h-4.3zm-25.1 13.9c0 6.9 4.6 9.6 9.3 9.6a9.7 9.7 0 0 0 8.7-5.3v4.6h4.1v-26.1h-4.1v14.6c0 5.2-3.6 8.5-7.7 8.5s-6.2-2-6.2-6.1v-17h-4.1zm-2.4-17.7-1.8-.2c-3.7 0-6.2 2.3-7.6 5.4v-4.7h-4.1v26.1h4.1v-14.3c0-5.3 3.1-8.7 6.6-8.7a7.1 7.1 0 0 1 2.1.3zm-32.3 3.8h4.4v16.5c0 5.3 3.2 7 6.5 7a10.8 10.8 0 0 0 3.5-.4l-.4-3.5a5.8 5.8 0 0 1 -1.9.3c-3.1 0-3.6-1.4-3.6-4.2v-15.7h6v-3.3h-6v-7h-4.1v7h-4.4zm-23.4-5.2c0-3.7 3.5-5.8 8-5.8s8.2 2.7 9.8 7.2l3.5-2.1c-1.8-5.4-6.7-8.8-13.3-8.8s-12.3 3.9-12.3 9.5 5.1 9.3 12.1 10.6 9.8 3.2 9.8 7.5-3.2 6.7-8.9 6.7-9.8-3.1-10.8-9.5l-3.9 2c1.1 6.3 6.3 11.4 14.7 11.4s13.3-4.9 13.3-11-4-9.2-11.9-10.7-10.1-3.4-10.1-7"/><path d="m119.3 57a2.7 2.7 0 0 0 -3-2.9 3.2 3.2 0 0 0 -2.9 1.7v-1.5h-1.3v8.5h1.3v-4.7a2.6 2.6 0 0 1 2.5-2.8 1.8 1.8 0 0 1 2 2v5.5h1.4zm-13.2-1.8a2.7 2.7 0 0 1 2.8 2.5h-5.6a2.8 2.8 0 0 1 2.8-2.5m4.1 3.6v-.5a3.9 3.9 0 0 0 -4.1-4.2 4.5 4.5 0 0 0 0 8.9 4.1 4.1 0 0 0 3.9-2.4l-1-.6a3 3 0 0 1 -2.9 1.9c-1.8 0-2.8-1.3-2.9-3.1zm-14-3.4h1.5v5.4a1.9 1.9 0 0 0 2.1 2.2h1.1v-1.2h-.6c-1 0-1.2-.5-1.2-1.4v-5h2v-1.1h-2.1v-2.3h-1.3v2.3h-1.5zm-6.1-4.6h-1.4v12h1.4v-3.7l.9-1 3 4.7h1.5l-3.5-5.6 2.9-2.9h-1.6l-3.2 3.2zm-7.4 4.4a2.7 2.7 0 0 1 2.8 2.5h-5.6a2.8 2.8 0 0 1 2.8-2.5m4.1 3.6v-.5a3.9 3.9 0 0 0 -4.1-4.2 4.5 4.5 0 0 0 0 8.9 4.1 4.1 0 0 0 3.9-2.4l-1-.6a2.9 2.9 0 0 1 -2.9 1.9 3 3 0 0 1 -2.9-3.1zm-13.9-3.4h1.4v5.4a1.9 1.9 0 0 0 2.1 2.2h1.1v-1.2h-.6c-1 0-1.2-.5-1.2-1.4v-5h2v-1.1h-2v-2.3h-1.4v2.3h-1.4zm-3.1-2.6h1.6v-1.7h-1.6zm.1 10h1.3v-8.5h-1.3zm-2.4-5.7a2.9 2.9 0 0 0 -3.1-3 3.2 3.2 0 0 0 -2.9 1.7v-5h-1.3v12h1.3v-4.7a2.6 2.6 0 0 1 2.6-2.8 1.8 1.8 0 0 1 2 2v5.5h1.4zm-9.9 2.9a3.1 3.1 0 0 1 -2.9 1.8 3 3 0 0 1 -3-3.3 2.9 2.9 0 0 1 3-3.2 2.9 2.9 0 0 1 2.8 1.8l1-.7a3.8 3.8 0 0 0 -3.8-2.3 4.5 4.5 0 0 0 0 8.9 4 4 0 0 0 3.8-2.4zm-7.7-5.9h-.6a2.5 2.5 0 0 0 -2.4 1.7v-1.5h-1.4v8.5h1.4v-4.6c0-1.8 1-2.9 2.1-2.9h.7l.2-1.3zm-11.2-.7.3-1a9.4 9.4 0 0 1 .4 1l1.8 4.7h-4.4zm-5.2 9.4h1.5l1.4-3.5h5.3l1.4 3.5h1.5l-4.8-12h-1.5z"/></g></svg>',
        scaledSize: new google.maps.Size(100, 94)
      }
    }); 
	};
	
	return {
		init: _initialize,
	}
})();

// Initialize
MapsUi.init();